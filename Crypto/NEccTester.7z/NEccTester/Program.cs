﻿using System;
using Ecc;
using System.Numerics;

namespace NEccTester
{
    class Program
    {
        static void Main(string[] args)
        {
            var curve = ECCurve.Secp256k1;
            var keyPair = curve.CreateKeyPair();
            Console.WriteLine(keyPair.D.ToHexUnsigned(32));
            Console.WriteLine(keyPair.PublicKey.Point.X.ToHexUnsigned(32));
            Console.WriteLine(keyPair.PublicKey.Point.Y.ToHexUnsigned(32));

            var msg = new BigInteger(4579485729345);
            
            var signature = keyPair.Sign(msg);
            Console.WriteLine(signature.S.ToHexUnsigned(32)); 
            var valid = keyPair.PublicKey.VerifySignature(msg, signature);
            Console.WriteLine(valid);
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}